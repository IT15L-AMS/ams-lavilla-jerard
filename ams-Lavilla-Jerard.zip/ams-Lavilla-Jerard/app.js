const state = {
  user: null,
  currentView: "dashboard",
};

const ROLE_CONFIG = {
  admin: {
    label: "Admin",
    menu: [
      { id: "dashboard", label: "Dashboard", icon: "📊" },
      { id: "students", label: "Students", icon: "🎓" },
      { id: "courses", label: "Courses", icon: "📚" },
      { id: "enrollments", label: "Enrollments", icon: "📝" },
      { id: "reports", label: "Reports", icon: "📈" },
    ],
  },
  instructor: {
    label: "Instructor",
    menu: [
      { id: "dashboard", label: "Dashboard", icon: "📊" },
      { id: "courses", label: "My Courses", icon: "📚" },
      { id: "enrollments", label: "Enrollments", icon: "📝" },
      { id: "reports", label: "Reports", icon: "📈" },
    ],
  },
  student: {
    label: "Student",
    menu: [
      { id: "dashboard", label: "Dashboard", icon: "📊" },
      { id: "courses", label: "My Courses", icon: "📚" },
      { id: "enrollments", label: "Enrollment", icon: "📝" },
      { id: "reports", label: "Progress", icon: "📈" },
    ],
  },
};

const MOCK_COUNTS = {
  students: 1287,
  courses: 84,
  enrollments: 3120,
  pending: 18,
};

const MOCK_STUDENTS = [
  {
    id: "2023-0001",
    name: "Alice Johnson",
    program: "BS Computer Science",
    year: "3rd",
    status: "Active",
  },
  {
    id: "2023-0012",
    name: "Brian Kim",
    program: "BS Information Technology",
    year: "2nd",
    status: "Active",
  },
  {
    id: "2022-0008",
    name: "Carla Santos",
    program: "BS Mathematics",
    year: "4th",
    status: "On Leave",
  },
  {
    id: "2024-0003",
    name: "David Lee",
    program: "BS Computer Science",
    year: "1st",
    status: "Active",
  },
];

const MOCK_COURSES = [
  {
    code: "CS101",
    title: "Introduction to Programming",
    department: "Computer Science",
    units: 3,
    term: "1st Sem 2025-2026",
    instructor: "Dr. Maria Dizon",
    status: "Open",
    schedule: "Mon & Wed 09:00 - 10:30",
  },
  {
    code: "IT202",
    title: "Database Systems",
    department: "Information Technology",
    units: 3,
    term: "1st Sem 2025-2026",
    instructor: "Engr. Ronel Cruz",
    status: "Open",
    schedule: "Tue & Thu 13:00 - 14:30",
  },
  {
    code: "MATH205",
    title: "Discrete Mathematics",
    department: "Mathematics",
    units: 3,
    term: "1st Sem 2025-2026",
    instructor: "Prof. Leah Gomez",
    status: "Closed",
    schedule: "Mon & Wed 11:00 - 12:30",
  },
];

const MOCK_ENROLLMENTS = [
  {
    id: "REQ-2312",
    student: "Alice Johnson",
    course: "CS101",
    term: "1st Sem 2025-2026",
    date: "2025-07-21",
    status: "Pending",
  },
  {
    id: "REQ-2313",
    student: "Brian Kim",
    course: "IT202",
    term: "1st Sem 2025-2026",
    date: "2025-07-21",
    status: "Approved",
  },
  {
    id: "REQ-2314",
    student: "David Lee",
    course: "CS101",
    term: "1st Sem 2025-2026",
    date: "2025-07-22",
    status: "Pending",
  },
];

const MOCK_REPORT = {
  totalStudents: 1287,
  totalEnrollments: 3120,
  avgClassSize: 37.1,
  growth: "+8.4%",
  perDepartment: [
    { department: "Computer Science", enrollments: 980 },
    { department: "Information Technology", enrollments: 740 },
    { department: "Mathematics", enrollments: 310 },
    { department: "Engineering", enrollments: 520 },
    { department: "Business", enrollments: 570 },
  ],
};

function $(selector) {
  return document.querySelector(selector);
}

function createEl(tag, opts = {}) {
  const el = document.createElement(tag);
  if (opts.className) el.className = opts.className;
  if (opts.text) el.textContent = opts.text;
  if (opts.html) el.innerHTML = opts.html;
  return el;
}

function formatStatusPill(status) {
  const s = status.toLowerCase();
  const base = "pill";
  if (s === "pending") return `<span class="${base} pending"><span class="pill-dot"></span> Pending</span>`;
  if (s === "approved") return `<span class="${base} approved"><span class="pill-dot"></span> Approved</span>`;
  if (s === "rejected") return `<span class="${base} rejected"><span class="pill-dot"></span> Rejected</span>`;
  return `<span class="${base}">${status}</span>`;
}

function renderSidebar() {
  const sidebarMenu = $("#sidebar-menu");
  sidebarMenu.innerHTML = "";
  if (!state.user) return;

  const roleConfig = ROLE_CONFIG[state.user.role];
  roleConfig.menu.forEach((item) => {
    const navItem = createEl("div", { className: "nav-item" });
    if (item.id === state.currentView) {
      navItem.classList.add("active");
    }
    navItem.dataset.view = item.id;
    navItem.innerHTML = `
      <span class="nav-icon">${item.icon}</span>
      <span>${item.label}</span>
    `;
    navItem.addEventListener("click", () => {
      navigateTo(item.id);
    });
    sidebarMenu.appendChild(navItem);
  });
}

function updateTopbar() {
  if (!state.user) return;
  $("#user-name").textContent = state.user.name;
  $("#user-role").textContent = ROLE_CONFIG[state.user.role].label;
  $("#user-avatar").textContent = state.user.name.charAt(0).toUpperCase();

  const titleEl = $("#page-title");
  const subtitleEl = $("#page-subtitle");

  switch (state.currentView) {
    case "dashboard":
      titleEl.textContent = "Dashboard";
      subtitleEl.textContent = "High-level overview of academic operations.";
      break;
    case "students":
      titleEl.textContent = "Students";
      subtitleEl.textContent =
        state.user.role === "admin"
          ? "Manage student records, profiles, and history."
          : "View students relevant to your courses.";
      break;
    case "courses":
      titleEl.textContent =
        state.user.role === "instructor"
          ? "My Courses"
          : state.user.role === "student"
          ? "My Courses & Catalog"
          : "Courses";
      subtitleEl.textContent =
        "Browse and manage course offerings for the term.";
      break;
    case "enrollments":
      titleEl.textContent =
        state.user.role === "student"
          ? "Enrollment"
          : "Enrollment Requests & Records";
      subtitleEl.textContent =
        "Track enrollment requests, approvals, and schedules.";
      break;
    case "reports":
      titleEl.textContent =
        state.user.role === "student" ? "Progress Overview" : "Reports";
      subtitleEl.textContent =
        "Key academic metrics and simple visual summaries.";
      break;
    default:
      titleEl.textContent = "Academic Management System";
      subtitleEl.textContent = "";
  }
}

function navigateTo(viewId) {
  state.currentView = viewId;
  renderSidebar();
  updateTopbar();
  renderCurrentView();
}

function renderDashboard() {
  const container = $("#view-container");
  const role = state.user.role;

  const roleTitle =
    role === "admin"
      ? "System Health"
      : role === "instructor"
      ? "My Teaching Overview"
      : "My Academic Snapshot";

  container.innerHTML = `
    <section class="grid grid-4">
      <div class="kpi-card">
        <div class="kpi-label">Total Students</div>
        <div class="kpi-value">${MOCK_COUNTS.students.toLocaleString()}</div>
        <div class="kpi-footnote">
          <span class="kpi-dot" style="background:#22c55e"></span>
          +3.2% vs last term
        </div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Courses this term</div>
        <div class="kpi-value">${MOCK_COUNTS.courses}</div>
        <div class="kpi-footnote">
          <span class="kpi-dot" style="background:#6366f1"></span>
          Departments: CS, IT, Math, Eng, Business
        </div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Active Enrollments</div>
        <div class="kpi-value">${MOCK_COUNTS.enrollments.toLocaleString()}</div>
        <div class="kpi-footnote">
          Avg class size ~37 students
        </div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Pending Requests</div>
        <div class="kpi-value">${MOCK_COUNTS.pending}</div>
        <div class="kpi-footnote">
          <span class="kpi-dot" style="background:#f97316"></span>
          Awaiting action by admins
        </div>
      </div>
    </section>

    <section class="grid grid-2">
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">${roleTitle}</div>
            <div class="card-subtitle">
              A quick glance at the term so far.
            </div>
          </div>
          <span class="badge-muted">1st Sem 2025-2026</span>
        </div>
        <div class="schedule-grid">
          <div class="schedule-item">
            <div>
              <div style="font-size:13px;font-weight:500;">Enrollment flow</div>
              <div class="text-muted">Requests ➝ Approval ➝ Enrollment</div>
            </div>
            <span class="chip info">Smooth</span>
          </div>
          <div class="schedule-item">
            <div>
              <div style="font-size:13px;font-weight:500;">Course capacity</div>
              <div class="text-muted">Most sections are 70–85% filled.</div>
            </div>
            <span class="chip success">Healthy</span>
          </div>
          <div class="schedule-item">
            <div>
              <div style="font-size:13px;font-weight:500;">Reporting</div>
              <div class="text-muted">Core metrics are up to date.</div>
            </div>
            <span class="chip warning">Monitor</span>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">Recent Enrollment Requests</div>
            <div class="card-subtitle">
              Latest 3 simulated requests from students.
            </div>
          </div>
          <button class="btn subtle" type="button">View all</button>
        </div>
        <table class="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Student</th>
              <th>Course</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${MOCK_ENROLLMENTS.map(
              (e) => `
              <tr>
                <td>${e.id}</td>
                <td>${e.student}</td>
                <td>${e.course}</td>
                <td>${formatStatusPill(e.status)}</td>
              </tr>
            `
            ).join("")}
          </tbody>
        </table>
      </div>
    </section>
  `;
}

function renderStudents() {
  const container = $("#view-container");
  const isAdmin = state.user.role === "admin";

  container.innerHTML = `
    <section class="card">
      <div class="toolbar">
        <div class="toolbar-left">
          <input class="input-small" id="students-search" placeholder="Search by name, ID, or program" />
          <select class="input-small" id="students-filter-program">
            <option value="">All programs</option>
            <option>BS Computer Science</option>
            <option>BS Information Technology</option>
            <option>BS Mathematics</option>
          </select>
          <select class="input-small" id="students-filter-year">
            <option value="">All years</option>
            <option>1st</option>
            <option>2nd</option>
            <option>3rd</option>
            <option>4th</option>
          </select>
        </div>
        <div class="toolbar-right">
          ${
            isAdmin
              ? '<button class="btn primary" type="button">+ Add Student</button>'
              : ""
          }
        </div>
      </div>
      <table class="table" id="students-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Program</th>
            <th>Year</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${MOCK_STUDENTS.map(
            (s) => `
            <tr>
              <td>${s.id}</td>
              <td>${s.name}</td>
              <td>${s.program}</td>
              <td>${s.year}</td>
              <td><span class="chip ${
                s.status === "Active" ? "success" : "warning"
              }">${s.status}</span></td>
              <td>
                <div class="table-actions">
                  <button class="btn subtle" type="button">View</button>
                  ${
                    isAdmin
                      ? '<button class="btn subtle" type="button">Edit</button>'
                      : ""
                  }
                </div>
              </td>
            </tr>
          `
          ).join("")}
        </tbody>
      </table>
      <div class="mt-3 flex-between">
        <span class="text-muted">Showing ${
          MOCK_STUDENTS.length
        } of ${MOCK_STUDENTS.length} students (mock data)</span>
        <span class="badge-muted">Pagination placeholder</span>
      </div>
    </section>
  `;
}

function renderCourses() {
  const container = $("#view-container");
  const role = state.user.role;
  const titleNote =
    role === "student"
      ? "Browse available courses and your current load."
      : "Courses open for teaching and enrollment.";

  container.innerHTML = `
    <section class="card">
      <div class="toolbar">
        <div class="toolbar-left">
          <input class="input-small" id="courses-search" placeholder="Search by code or title" />
          <select class="input-small">
            <option value="">All departments</option>
            <option>Computer Science</option>
            <option>Information Technology</option>
            <option>Mathematics</option>
          </select>
          <select class="input-small">
            <option value="">All statuses</option>
            <option>Open</option>
            <option>Closed</option>
          </select>
        </div>
        <div class="toolbar-right">
          ${
            role === "admin"
              ? '<button class="btn primary" type="button">+ Add Course</button>'
              : ""
          }
        </div>
      </div>
      <p class="text-muted mt-2">${titleNote}</p>
      <table class="table mt-2">
        <thead>
          <tr>
            <th>Code</th>
            <th>Title</th>
            <th>Department</th>
            <th>Units</th>
            <th>Term</th>
            <th>Instructor</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${MOCK_COURSES.map(
            (c) => `
            <tr>
              <td>${c.code}</td>
              <td>${c.title}</td>
              <td>${c.department}</td>
              <td>${c.units}</td>
              <td>${c.term}</td>
              <td>${c.instructor}</td>
              <td>
                <span class="chip ${
                  c.status === "Open" ? "success" : "warning"
                }">${c.status}</span>
              </td>
              <td>
                <div class="table-actions">
                  <button class="btn subtle" type="button">View</button>
                  ${
                    role === "student"
                      ? '<button class="btn primary" type="button">Request</button>'
                      : ""
                  }
                </div>
              </td>
            </tr>
          `
          ).join("")}
        </tbody>
      </table>
    </section>
  `;
}

function renderEnrollments() {
  const container = $("#view-container");
  const role = state.user.role;

  if (role === "student") {
    container.innerHTML = `
      <section class="grid grid-2">
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">Available Courses</div>
              <div class="card-subtitle">
                Filter and request enrollment for the term.
              </div>
            </div>
            <span class="badge-muted">1st Sem 2025-2026</span>
          </div>
          <div class="toolbar mt-2">
            <div class="toolbar-left">
              <input class="input-small" placeholder="Filter by code or title" />
              <select class="input-small">
                <option value="">All schedules</option>
                <option>Morning</option>
                <option>Afternoon</option>
              </select>
            </div>
          </div>
          <table class="table mt-2">
            <thead>
              <tr>
                <th>Course</th>
                <th>Schedule</th>
                <th>Slots</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              ${MOCK_COURSES.map(
                (c) => `
                <tr>
                  <td>
                    <div style="font-size:13px;font-weight:500;">${
                      c.code
                    } · ${c.title}</div>
                    <div class="text-muted">${c.instructor}</div>
                  </td>
                  <td>${c.schedule}</td>
                  <td><span class="badge-outline">Simulated slots</span></td>
                  <td>
                    <button class="btn primary" type="button">Request</button>
                  </td>
                </tr>
              `
              ).join("")}
            </tbody>
          </table>
        </div>

        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">My Requests & Schedule</div>
              <div class="card-subtitle">
                Track the status of your enrollment requests.
              </div>
            </div>
          </div>
          <table class="table">
            <thead>
              <tr>
                <th>Course</th>
                <th>Term</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${MOCK_ENROLLMENTS.map(
                (e) => `
                <tr>
                  <td>${e.course}</td>
                  <td>${e.term}</td>
                  <td>${formatStatusPill(e.status)}</td>
                </tr>
              `
              ).join("")}
            </tbody>
          </table>
          <p class="text-muted mt-3">
            This is a static mock schedule. Integrate with your backend to
            persist enrollment decisions, conflicts, and credit limits.
          </p>
        </div>
      </section>
    `;
    return;
  }

  container.innerHTML = `
    <section class="card">
      <div class="toolbar">
        <div class="toolbar-left">
          <select class="input-small">
            <option>1st Sem 2025-2026</option>
            <option>2nd Sem 2025-2026</option>
          </select>
          <select class="input-small">
            <option value="">All statuses</option>
            <option>Pending</option>
            <option>Approved</option>
            <option>Rejected</option>
          </select>
        </div>
        <div class="toolbar-right">
          <button class="btn subtle" type="button">Bulk approve (mock)</button>
        </div>
      </div>
      <table class="table">
        <thead>
          <tr>
            <th>Request ID</th>
            <th>Student</th>
            <th>Course</th>
            <th>Term</th>
            <th>Requested</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${MOCK_ENROLLMENTS.map(
            (e) => `
            <tr>
              <td>${e.id}</td>
              <td>${e.student}</td>
              <td>${e.course}</td>
              <td>${e.term}</td>
              <td>${e.date}</td>
              <td>${formatStatusPill(e.status)}</td>
              <td>
                <div class="table-actions">
                  <button class="btn subtle" type="button">Approve</button>
                  <button class="btn subtle" type="button">Reject</button>
                </div>
              </td>
            </tr>
          `
          ).join("")}
        </tbody>
      </table>
      <p class="text-muted mt-3">
        All data in this prototype is simulated. Replace with API calls to show
        live enrollment queues and instructor approvals.
      </p>
    </section>
  `;
}

function renderReports() {
  const container = $("#view-container");
  const role = state.user.role;

  container.innerHTML = `
    <section class="grid grid-4">
      <div class="kpi-card">
        <div class="kpi-label">Students this term</div>
        <div class="kpi-value">${MOCK_REPORT.totalStudents.toLocaleString()}</div>
        <div class="kpi-footnote">Unique student records</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Total enrollments</div>
        <div class="kpi-value">${MOCK_REPORT.totalEnrollments.toLocaleString()}</div>
        <div class="kpi-footnote">Across all departments</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Average class size</div>
        <div class="kpi-value">${MOCK_REPORT.avgClassSize}</div>
        <div class="kpi-footnote">Students per section (approx.)</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Enrollment growth</div>
        <div class="kpi-value">${MOCK_REPORT.growth}</div>
        <div class="kpi-footnote">Compared to previous term</div>
      </div>
    </section>

    <section class="grid grid-2">
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">Enrollments per Department</div>
            <div class="card-subtitle">
              Simple bar-style representation of department load.
            </div>
          </div>
          <button class="btn subtle" type="button">Export CSV</button>
        </div>
        <div class="mt-2">
          ${MOCK_REPORT.perDepartment
            .map((row) => {
              const pct = Math.round(
                (row.enrollments / MOCK_REPORT.totalEnrollments) * 100
              );
              return `
                <div class="mt-2">
                  <div class="flex-between">
                    <span style="font-size:13px;">${row.department}</span>
                    <span class="text-muted">${row.enrollments} · ${pct}%</span>
                  </div>
                  <div style="height:6px;border-radius:999px;background:#e5e7eb;overflow:hidden;margin-top:4px;">
                    <div style="width:${pct}%;height:100%;background:linear-gradient(90deg,#2563eb,#22c55e);"></div>
                  </div>
                </div>
              `;
            })
            .join("")}
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">
              ${role === "student" ? "My Progress (Mock)" : "Largest Courses (Mock)"}
            </div>
            <div class="card-subtitle">
              Replace with real grade or enrollment data from your backend.
            </div>
          </div>
          <button class="btn subtle" type="button">Print</button>
        </div>
        ${
          role === "student"
            ? `
              <p class="text-muted">
                This demo does not compute real grades. It only illustrates how a
                progress card might look in a production AMS.
              </p>
              <div class="mt-3">
                <div class="flex-between">
                  <span>Estimated standing</span>
                  <span class="chip info">Good</span>
                </div>
                <div class="mt-2">
                  <div class="flex-between">
                    <span class="text-muted">Completed units</span>
                    <span>72 / 120</span>
                  </div>
                  <div class="flex-between mt-1">
                    <span class="text-muted">Estimated GPA</span>
                    <span>1.75 (mock)</span>
                  </div>
                </div>
              </div>
            `
            : `
              <table class="table">
                <thead>
                  <tr>
                    <th>Course</th>
                    <th>Department</th>
                    <th>Enrollments</th>
                  </tr>
                </thead>
                <tbody>
                  ${MOCK_REPORT.perDepartment
                    .slice()
                    .reverse()
                    .map(
                      (row) => `
                      <tr>
                        <td>Sample course · ${row.department}</td>
                        <td>${row.department}</td>
                        <td>${row.enrollments}</td>
                      </tr>
                    `
                    )
                    .join("")}
                </tbody>
              </table>
            `
        }
      </div>
    </section>
  `;
}

function renderCurrentView() {
  switch (state.currentView) {
    case "dashboard":
      renderDashboard();
      break;
    case "students":
      renderStudents();
      break;
    case "courses":
      renderCourses();
      break;
    case "enrollments":
      renderEnrollments();
      break;
    case "reports":
      renderReports();
      break;
    default:
      renderDashboard();
  }
}

function handleLogin(e) {
  e.preventDefault();
  const username = $("#login-username").value.trim();
  const role = $("#login-role").value;

  if (!username || !role) return;

  state.user = {
    name: username,
    role,
  };
  state.currentView = "dashboard";

  $("#login-view").classList.add("hidden");
  $("#main-shell").classList.remove("hidden");

  renderSidebar();
  updateTopbar();
  renderCurrentView();
}

function handleLogout() {
  state.user = null;
  state.currentView = "dashboard";
  $("#main-shell").classList.add("hidden");
  $("#login-view").classList.remove("hidden");
}

function init() {
  $("#login-form").addEventListener("submit", handleLogin);
  $("#logout-btn").addEventListener("click", handleLogout);
}

document.addEventListener("DOMContentLoaded", init);

